#ifndef __CATCH_TASK_H_
#define __CATCH_TASK_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "include.h"

fp32 servo_motor_angle_calc(fp32 set_angle);



#ifdef __cplusplus
}
#endif

#endif

