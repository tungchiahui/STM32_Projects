#ifndef __SHOOT_H_
#define __SHOOT_H_


#ifdef __cplusplus
extern "C"
{
#endif

#include "include.h"


#ifdef __cplusplus
}
#endif

#endif
