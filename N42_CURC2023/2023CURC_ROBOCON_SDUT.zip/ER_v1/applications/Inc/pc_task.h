#ifndef __PC_TASK_H_
#define __PC_TASK_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "include.h"

void Tuning_PID(uint8_t *pc_rx);

#ifdef __cplusplus
}
#endif

#endif
