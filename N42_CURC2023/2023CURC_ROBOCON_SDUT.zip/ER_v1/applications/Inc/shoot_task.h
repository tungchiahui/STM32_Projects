#ifndef __SHOOT_TASK_H_
#define __SHOOT_TASK_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "include.h"
fp32 accel_optimize(fp32 speed_target,fp32 interval_time);
#ifdef __cplusplus
}
#endif

#endif
